
#include <iostream>
#include <vector>
using namespace std;

bool inStr(string s1, string s2){
    if (s1.find(s2) != string::npos) {
        return true;
    }
    else {
        return false;
    }
}

template<typename type0 >auto print(type0 a ) {
cout << a << endl;

}class Dog {
public:
string a="";
Dog () {
cout << "Hello Classes!" << endl;

}
auto bark() {
print("bark!");

}

};auto start() {
auto d=Dog();
d.bark();

}

int main() {


start();

}