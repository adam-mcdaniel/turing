

import os
# import _ctypes

def inStr(s1, s2):
	return (s1 in s2)

def read():
	return input()

def write(a):
	print(a, end='')

def writeln(a):
	print(a)

def get_char():
	return input()[0]

def Add(a, b):
	return a+b

def Sub(a, b):
	return a-b

def Negative(a):
	return -a

def Mul(a, b):
	return a*b

def Div(a, b):
	return int(a/b)

def Int(a):
	return int(a)

def String(a):
	return str(a)

def Is(a, b):
	return (a==b)

def In(a, b):
	return (a in b)

def Not(a):
	return (not a)

def And(a, b):
	return (a and b)

def Or(a, b):
	return (a or b)

def Greater(a, b):
	return (a > b)

def Less(a, b):
	return (a < b)

# def dereference(obj_id):
#     return _ctypes.PyObj_FromPtr(obj_id)

def append(a, b):
	c = list(a)
	c.append(b)
	return c

def empty(a):
	return []

def console(a):
	os.system(a)


from wpilib import *

from networktables import *

from ctre import *

class MyRobot(IterativeRobot):

	
	right_a = None
	
	right_b = None
	
	left_a = None
	
	left_b = None
	
	robot_drive = None
	
	
	winch = None
	
	
	compressor = None
	
	gearGrabber = None
	
	
	stick = None
	
	buttons = None
	
	
	gyro = None
	
	
	gyroPidOutput = None
	
	gyroPid = None
	
	
	sd = None
	
	
	def robotInit(this):
	
		this.right_a=CANTalon(1)
		this.right_b=CANTalon(2)
		this.left_a=CANTalon(3)
		this.left_b=CANTalon(4)
		this.right_a.setControlMode(CANTalon.ControlMode.PercentVbus)
		this.left_a.setControlMode(CANTalon.ControlMode.PercentVbus)
		this.right_b.setControlMode(CANTalon.ControlMode.PercentVbus)
		this.left_b.setControlMode(CANTalon.ControlMode.PercentVbus)
		this.robot_drive=RobotDrive(this.left_a,this.right_a,this.left_b,this.right_b)
		this.winch=CANTalon(5)
		this.compressor=Compressor()
		this.gearGrabber=DoubleSolenoid(6,0,1)
		this.stick=Joystick(0)
		this.buttons=Joystick(1)
		this.gyro=adxrs450_gyro.ADXRS450_Gyro()
		this.sd=NetworkTables.getTable("SmartDashboard")
		this.sd.putBoolean("DB/Button 1",True)
		dirs = []
		dirs=append(dirs,"left")
		dirs=append(dirs,"center")
		dirs=append(dirs,"right")
		this.sd.putStringArray("autonomous/options",dirs)
		this.sd.putString("autonomous/selected","left")
		
	
	def autonomousInit(this):
	
		pass
		
	
	def autonomousPeriodic(this):
	
		pass
		
	
	def teleopInit(this):
	
		pass
		
	
	def teleopPeriodic(this):
	
		this.robot_drive.arcadeDrive(Negative(1),1)
		if (this.buttons.getRawButton(1)):
		
			this.gearGrabber.set(DoubleSolenoid.Value.kReverse)
			
		
		else:
		
			this.gearGrabber.set(DoubleSolenoid.Value.kForward)
			
		
		if (this.buttons.getRawButton(6)):
		
			this.winch.set(Negative(1))
			
		
		elif (this.buttons.getRawButton(5)):
		
			this.winch.set(Negative(0.4))
			
		
		else:
		
			this.winch.set(0)
			
		
		if (this.stick.getRawButton(1)):
		
			this.robot_drive.arcadeDrive(Negative(this.stick.getY()),Mul(this.stick.getAxis(2),0.83))
			
		
		elif (this.stick.getRawButton(2)):
		
			this.robot_drive.arcadeDrive(Mul(Negative(this.stick.getY()),0.51),Mul(this.stick.getAxis(2),0.43))
			
		
		else:
		
			this.robot_drive.arcadeDrive(Mul(Negative(this.stick.getY()),0.91),Mul(this.stick.getAxis(2),0.63))
			
		
		
	
	def testPeriodic(this):
	
		LiveWindow.run()
		
	
	

if (Is(__name__,"__main__")):

	run(MyRobot)
	

