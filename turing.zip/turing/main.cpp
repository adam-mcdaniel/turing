
#include <iostream>
#include <vector>
using namespace std;

int main() {
cout << "Hello World!" << endl;
int a=0;
int b=a;
while ( b <    20 ) {
cout << ":";
if (( b-2 ) ==    0 ) {
cout << "b is 2!" << endl;

}
else if (( b-4 ) ==    0 ) {
cout << "b is 4!" << endl;

}
else if (( b-8 ) ==    0 ) {
cout << "b is 8!" << endl;

}
else if (( b-16 ) ==    0 ) {
cout << "b is 16!" << endl;

}
else {
cout << b << endl;

}
b+=1;

}
bool c=true;
if (( c ==    true )) {
cout << "Goodbye World!" << endl;

}
}