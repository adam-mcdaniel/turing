


class X:
	def __init__(this):
		this.x = 9
		print(this.x)
		# this = X()

y = X()


def Or(a, b):
	return a or b

print(Or(True, True))