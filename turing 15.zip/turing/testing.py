condition = 1

# the variable condition is now 1

while condition < 10:
	# while the variable condition is less than 10

	print(condition)

	condition += 1
	# add one to condition
	# back to line 5