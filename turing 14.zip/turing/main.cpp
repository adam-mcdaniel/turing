
#include <iostream>
#include <vector>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

template<typename T>
auto __Type__()
{
	T a;
	return a;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}


string read()
{
	string a;
	getline(cin, a);
	return a;
}


template<typename T>
void print(T a)
{
	cout<<a;
}

template<typename T>
void println(T a)
{
	cout<<a<<endl;
}

string get_char()
{
	string s;
 	stringstream ss;

	getline(cin, s);

	if (s.size() > 0)
	{
	 	ss << s.at(0);
	 	ss >> s;
	} else {
		s = " ";
	}

	return s;
}

template<typename T, typename T2>
auto Add(T a, T2 b)
{
	return a+b;
}

int Sub(int a, int b)
{
	return a-b;
}

int Negative(int a)
{
	return -a;
}

template<typename T, typename T2>
auto Mul(T a, T2 b)
{
	return a*b;
}

int Div(int a, int b)
{
	return a/b;
}


template<typename T>
auto Int(T a)
{
	int c = 0;
	stringstream b(a);
	b >> c;
	return c;
}

template<typename T>
auto String(T a)
{
	stringstream b;
	b << a;
	string c = b.str();
	return c;
}

template<typename T, typename T2>
auto Is(T a, T2 b)
{
	return (a==b);
}

template<typename T>
auto Not(T a)
{
	return (!a);
}

template<typename T, typename T2>
auto And(T a, T2 b)
{
	return (a&&b);
}

template<typename T, typename T2>
auto Or(T a, T2 b)
{
	return (a||b);
}

auto console(string a)
{
	system(a.c_str());
}

template<typename T, typename T2>
auto append(T a, T2 b)
{
	auto c = a;
	c.push_back(b);
	return c;
}

template<typename T>
auto len(T a)
{
	return a.size();
}

template<typename T>
auto empty(T a)
{
	a.empty();
	return a;
}



int main(int argc,char* __char_argv__[])
{

	string __file__ = *__char_argv__;
__auto_reserved__(listOfFunctions, __List__<vector<int>>());
__auto_reserved__(empty, __List__<int>());
listOfFunctions=append(listOfFunctions,empty);
listOfFunctions[0]=append(listOfFunctions[0],29);
println(listOfFunctions[0][0]);

	return 0;

}

