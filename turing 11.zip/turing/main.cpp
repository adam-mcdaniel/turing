
#include <iostream>
#include <vector>
#include <sstream>
#include <string>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

template<typename T>
auto __Type__()
{
	T a;
	return a;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}


string read()
{
	string a;
	getline(cin, a);
	return a;
}


template<typename T>
void print(T a)
{
	cout<<a;
}

template<typename T>
void println(T a)
{
	cout<<a<<endl;
}

string get_char()
{
	string s;
 	stringstream ss;

	getline(cin, s);

	if (s.size() > 0)
	{
	 	ss << s.at(0);
	 	ss >> s;
	} else {
		s = " ";
	}

	return s;
}

template<typename T, typename T2>
auto Add(T a, T2 b)
{
	return a+b;	
}

int Sub(int a, int b)
{
	return a-b;	
}

int Negative(int a)
{
	return -a;	
}

template<typename T, typename T2>
auto Mul(T a, T2 b)
{
	return a*b;	
}

int Div(int a, int b)
{
	return a/b;	
}


template<typename T>
auto Int(T a)
{
	int c = 0;
	stringstream b(a);
	b >> c;
	return c;
}

template<typename T>
auto String(T a)
{
	stringstream b;
	b << a;
	string c = b.str();
	return c;
}

template<typename T, typename T2>
auto Is(T a, T2 b)
{
	return (a==b);
}

template<typename T>
auto Not(T a)
{
	return (a);
}

template<typename T, typename T2>
auto And(T a, T2 b)
{
	return (a&&b);
}

template<typename T, typename T2>
auto Or(T a, T2 b)
{
	return (a||b);
}

#include "WPIlib.h"

class MyRobot: public IterativeRobot {
public:
__auto_reserved__(right_a, CANTalon(1));
__auto_reserved__(right_b, CANTalon(2));
__auto_reserved__(left_a, CANTalon(3));
__auto_reserved__(left_b, CANTalon(4));
__auto_reserved__(robotdrive, RobotDrive(left_a,right_a,left_b,right_b));
__auto_reserved__(stick, Joystick(0));

auto teleopPeriodic() {
robotdrive.arcadeDrive(Negative(stick.getY()),stick.getAxis(2));

}

};



int main(int argc,char* __char_argv__[])
{

	string __file__ = *__char_argv__;
START_ROBOT_CLASS(MyRobot);

	return 0;

}

