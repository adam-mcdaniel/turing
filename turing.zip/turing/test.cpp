# include <iostream>
# include <vector>
using namespace std;


template <class SomeType>
SomeType sum (SomeType a, SomeType b)
{
  return a+b;
}


int main() {
	cout << sum<int>(10,20) << endl;
}