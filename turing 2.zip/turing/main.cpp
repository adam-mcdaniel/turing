
#include <iostream>
#include <vector>
using namespace std;

template<typename type0 >auto print(type0 a ) {
cout << a << endl;

}auto run() {
while ( true ) {
print("Hello Functions!");

}

}int main() {

}