
#include <iostream>
#include <vector>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}

template<typename type0 >auto print(type0 a ) {
cout << a << endl;

}class Dog {
public:
string name="";
__auto_reserved__(list, __List__<vector<int>>());
__auto_reserved__(sub, __List__<int>());
template<typename type0 >
Dog (type0 a ) {
name=a;
auto i=0;
while ( i <    8 ) {
list.push_back(sub);
i+=1;

}
list[0]=range(0,8);
cout << "size of ";
cout << name;
cout << "'s list is: ";
cout << list.size() << endl;

}
auto bark() {
print("bark!");

}
auto print_name() {
print(name);

}

};auto new_dog() {
auto dog=Dog("adam");
return dog;

}auto start() {
auto dog=new_dog();
dog.print_name();

}

int main() {



start();

}