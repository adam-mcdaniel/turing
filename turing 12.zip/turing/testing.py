


class X:
	def __init__(this):
		this.x = 9
		print(this.x)
		# this = X()

y = X()