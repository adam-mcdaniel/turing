
#include <iostream>
// #include <map>
#include <vector>
using namespace std;

// template <typename T1, typename T2>
// auto mapp(T1 values, T2 fun) {
// 	std::vector<decltype(
// 		fun(std::declval<typename decltype(values)::value_type>()))> results{};
// 	for (auto v : values) {
// 		results.push_back(fun(v));
// 	}
// 	return results;
// }


class Dog
{        
public:
        
        std::string _name;
        int _age;
        
        Dog(std::string name, int age) {
        	_name = name;
        	_age = age;
        }
};

int main()
{
	auto d = Dog("Ginny", 9);
	cout << d._age << endl;
}