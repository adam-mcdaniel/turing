
#include <iostream>
#include <vector>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

template<typename T>
auto __Type__()
{
	T a;
	return a;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}


class Board {
public:
__auto_reserved__(board_list, __List__<vector<int>>());__auto_reserved__(empty_list, __List__<int>());__auto_reserved__(size, 0);
auto empty_board() {
for (auto x:range(0,size)) {
board_list[x].clear();

}
system("clear");

}
auto print_board() {
system("clear");
for (auto x:range(0,size)) {
for (auto y:range(0,size)) {
cout << board_list[y][x];

}
cout << "" << endl;

}

}
template<typename type0 >
Board (type0 _size ) {
size=_size;
for (auto x:range(0,size)) {
board_list.push_back(empty_list);

}
for (auto x:range(0,size)) {
for (auto y:range(0,size)) {
board_list[x].push_back(0);

}

}

}

};

auto start() {
auto b=Board(50);
while ( true ) {
b.print_board();
string a="";
getline(cin, a);

}

}



int main() {

start();

	return 0;

}

