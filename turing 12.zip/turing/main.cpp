
#include <iostream>
#include <vector>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

template<typename T>
auto __Type__()
{
	T a;
	return a;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}


string read()
{
	string a;
	getline(cin, a);
	return a;
}


template<typename T>
void print(T a)
{
	cout<<a;
}

template<typename T>
void println(T a)
{
	cout<<a<<endl;
}

string get_char()
{
	string s;
 	stringstream ss;

	getline(cin, s);

	if (s.size() > 0)
	{
	 	ss << s.at(0);
	 	ss >> s;
	} else {
		s = " ";
	}

	return s;
}

template<typename T, typename T2>
auto Add(T a, T2 b)
{
	/*
	if (typeid(a) == typeid(const char *()))
	{
		return strcat(a, b);
	}
	else if (typeid(a) == typeid(int()))
	{
		return a+b;
	}
	else if (typeid(a) == typeid(string()))
	{
		return a+b;
	}
	*/
	return a+b;
}

int Sub(int a, int b)
{
	return a-b;	
}

int Negative(int a)
{
	return -a;	
}

template<typename T, typename T2>
auto Mul(T a, T2 b)
{
	return a*b;	
}

int Div(int a, int b)
{
	return a/b;	
}


template<typename T>
auto Int(T a)
{
	int c = 0;
	stringstream b(a);
	b >> c;
	return c;
}

template<typename T>
auto String(T a)
{
	stringstream b;
	b << a;
	string c = b.str();
	return c;
}

template<typename T, typename T2>
auto Is(T a, T2 b)
{
	return (a==b);
}

template<typename T>
auto Not(T a)
{
	return (!a);
}

template<typename T, typename T2>
auto And(T a, T2 b)
{
	return (a&&b);
}

template<typename T, typename T2>
auto Or(T a, T2 b)
{
	return (a||b);
}

auto console(string a)
{
	system(a.c_str());
}
template<typename type0, typename type1 >auto Pow(type0 a, type1 b ) {
int c=1;
for (auto x:range(0,b)) {
c=Mul(a,c);

}
return c;

}

template<typename type0 >auto prompt(type0 a ) {
print(a);
auto b=read();
return b;

}

auto test() {
println("Okay");

}



int main(int argc,char* __char_argv__[])
{

	string __file__ = *__char_argv__;


auto x=Mul(Add(1,1),Add(1,1));
println(x);
auto nine_two=Add("9^2 is ",String(Pow(9,2)));
println(nine_two);
auto a=Int(prompt("(1>"));
auto b=Int(prompt("(2>"));
println(Pow(a,b));


	return 0;

}

