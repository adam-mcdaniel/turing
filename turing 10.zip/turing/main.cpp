
#include <iostream>
#include <vector>
#include <sstream>
#include <string>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

template<typename T>
auto __Type__()
{
	T a;
	return a;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}


string get_char()
{
	string s;
 	stringstream ss;

	getline(cin, s);

	if (s.size() > 0)
	{
	 	ss << s.at(0);
	 	ss >> s;
	} else {
		s = " ";
	}

	return s;
}

template<typename T, typename T2>
auto Add(T a, T2 b)
{
	return a+b;	
}

int Sub(int a, int b)
{
	return a-b;	
}

template<typename T, typename T2>
auto Mul(T a, T2 b)
{
	return a*b;	
}

int Div(int a, int b)
{
	return a/b;	
}

template<typename type0 >auto print(type0 a ) {
cout << a << endl;

}

class Dog {
public:
string name="";__auto_reserved__(list, __List__<vector<int>>());__auto_reserved__(sub, __List__<int>());
template<typename type0 >
Dog (type0 a ) {
name=a;
for (auto x:range(0,8)) {
list.push_back(sub);

}
list[0]=range(0,8);
cout << "size of ";
cout << name;
cout << "'s list is: ";
cout << list.size() << endl;

}
auto bark() {
print("bark!");

}
auto print_name() {
print(name);

}

};

auto new_dog() {
auto dog=Dog("adam");
return dog;

}

class Atom {
public:
string name="";__auto_reserved__(mass, 0);
auto print_info() {
print(name);
print(mass);

}
template<typename type0, typename type1 >
Atom (type0 n, type1 m ) {
name=n;
mass=m;

}

Atom () {
name="H";
mass=1;

}

};

class Mole {
public:
string number_of_atoms="6.022*10^23 atoms in a mole";__auto_reserved__(atoms, __List__<Atom>());
auto print_info() {
print(number_of_atoms);
for (auto atom:atoms) {
atom.print_info();

}

}
template<typename type0, typename type1 >auto print_moles(type0 a, type1 moles ) {
auto store_moles=Mul(a.mass,moles);
cout << store_moles;
cout << " grams of ";
cout << a.name;
cout << " in ";
cout << moles;
if ( moles ==    1 ) {
cout << " mole" << endl;

}
else {
cout << " moles" << endl;

}

}

Mole () {
print_info();

}

};

auto start() {
auto m=Mole();
auto atom=Atom("Ca",40);
m.print_moles(atom,1);
auto dog=new_dog();
dog.print_name();

}



int main(int argc,char* __char_argv__[])
{

	string __file__ = *__char_argv__;



start();

	return 0;

}

