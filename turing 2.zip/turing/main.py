import parsley, sys, os, pyparsing


listOfVariablesAndTypes = {}

listOfFunctions = []

def moveFunction(func):
	global listOfFunctions
	listOfFunctions.append(func)
	print(listOfFunctions)
	return ''

def checkVarInList(left, right, Type=""):
	global listOfVariablesAndTypes
	# print(listOfVariablesAndTypes)
	# print(left)
	if str(left) in listOfVariablesAndTypes:
		# print("in")
		return ""
		# pass
	else:
		listOfVariablesAndTypes[str(left)] = ""
		if Type == "var":
			# print("2:identifier")
			listOfVariablesAndTypes[str(left)] = listOfVariablesAndTypes[str(right)]
		else:

			if Type == "intlist":
				listOfVariablesAndTypes[str(left)] = "vector <int> "
				# print("2:intlist")

			elif Type == "int":
				listOfVariablesAndTypes[str(left)] = "int "
				# print("2:number")

			elif Type == "math":
				listOfVariablesAndTypes[str(left)] = "int "
				# print("2:math")

			elif Type == "strlist":
				listOfVariablesAndTypes[str(left)] = "vector <string> "
				# print("2:intlist")

			elif Type == "str":
				listOfVariablesAndTypes[str(left)] = "string "
				# print("2:string")
				
			elif Type == "bool":
				listOfVariablesAndTypes[str(left)] = "bool "
				# print("2:bool")

			elif Type == "functioncall":
				listOfVariablesAndTypes[str(left)] = "auto "
				# print("2:bool")

		# # print("type: " + listOfVariablesAndTypes[str(left)])
		if str(left) in listOfVariablesAndTypes:
			return str(listOfVariablesAndTypes[str(left)])
		else:
			return "auto"
		# return "auto "



def returnTemplate(listOfParameters):
	print(listOfParameters)
	changedList = []
	if len(listOfParameters) > 0:
		i = 0
		for j in listOfParameters[:-1]:
			changedList.append("typename type"+str(i)+", ")
			i += 1
		changedList.append("typename type"+str(i)+" ")
		return 'template<'+''.join(changedList)+'>'
	else:
		return ''

def returnTypedParameters(listOfParameters):
	print(listOfParameters)
	changedList = []
	if len(listOfParameters) > 0:
		i = 0
		for j in listOfParameters[:-1]:
			changedList.append("type"+str(i)+" "+listOfParameters[i]+", ")
			i += 1
		changedList.append("type"+str(i)+" "+listOfParameters[i]+" ")
		return ''.join(changedList)
	else:
		return ''


# print(returnTemplate(["a", "b"]))
# print(returnTypedParameters(["a", "b"]))

# sys.exit(0)

x = parsley.makeGrammar("""

allw = w endl w 

w = <(' ' | '\\t')*>
endl = <('\\n')*>

digit = anything:x ?(x in '0123456789')
number = <digit+>:ds -> str(ds)
letter = anything:x ?(x in 'abcdefghijklmnopqrstuvwxyz')

identifier = <letter+>:ds -> str(ds)
string = '"' (~'"' anything)*:c '"' -> '"' + ''.join(c) + '"' 

assign = ('=' | '+=' | '-='):a -> a

operator = anything:x ?(x in '*/+-()') -> str(x)


bool = ('True' | 'False'):a -> str(a).lower()

intlist = (
		'[' <(w number | ',')*>:a ']' -> "{" + a + "}"
		)
strlist = (
		'[' <(w string | ',')*>:a ']' -> "{" + a + "}"
		)

# vector <int> v = {1,2,3,4,5,6};
# for (int& s: v){
# 	cout << "The strings are: " << s << endl;
# }

math = (math:a w <operator*>:b w math:c -> str(a) + str(b) + str(c)
		| <operator+>:a w identifier:b w <operator+>:c -> str(a) + str(b) + str(c)
		| <operator+>:a w number:b w <operator+>:c -> str(a) + str(b) + str(c)
		| number:a w operator:b w number:c -> str(a) + str(b) + str(c)
		| number:a w operator:b w identifier:c -> str(a) + str(b) + str(c)
		| identifier:a w operator:b w number:c -> str(a) + str(b) + str(c)
		)

object = bool | number | math | string | identifier | intlist | strlist

compare = (w 'is' w|w 'and' w|w 'or' w|w 'not' w|w '>' w| w '<' w|w '(' w| w ')' w)
condition = (condition:a w <compare*>:b w condition:c -> str(a) + ' ' + str(b).replace('is', '==').replace('and', '&&').replace('or', '||').replace('not', '!') + ' ' + str(c)
			| <compare*>:a w object:b w <compare*>:c -> str(a).replace('is', '==').replace('and', '&&').replace('or', '||').replace('not', '!') + ' ' + str(b) + ' ' + str(c).replace('is', '==').replace('and', '&&').replace('or', '||').replace('not', '!')
			)

# whileloop = 'while' w identifier:a allw '[' allw statement*:b allw ']' w -> 'while (' + str(a) + ') {\\n' + ''.join(b) + '\\n}'
whileloop = '(' allw 'while' w condition:a allw statement*:b allw ')' allw -> 'while (' + str(a) + ') {\\n' + ''.join(b) + '\\n}'

if = '(' allw 'if' w condition:a allw statement*:b allw ')' allw -> 'if (' + str(a) + ') {\\n' + ''.join(b) + '\\n}'
elif = '(' allw 'elif' w condition:a allw statement*:b allw ')' allw -> 'else if (' + str(a) + ') {\\n' + ''.join(b) + '\\n}'
else = '(' allw 'else' allw statement*:a allw ')' allw -> 'else {\\n' + ''.join(a) + '\\n}'


comment = ';' <(~'\\n' anything)*> -> ''

past_assignment = identifier:left w assign:op w ( functioncall:right -> 		checkVarInList(left, right, "functioncall") + str(left) + str(op) + str(right)
										| math:right -> 						checkVarInList(left, right, "math") + str(left) + str(op) + str(right)
										| number:right -> 						checkVarInList(left, right, "int") + str(left) + str(op) + str(right)
										| string:right 	-> 						checkVarInList(left, right, "str") + str(left) + str(op) + str(right)
										| identifier:right -> 					checkVarInList(left, right, "var") + str(left) + str(op) + str(right)
										| bool:right -> 						checkVarInList(left, right, "bool") + str(left) + str(op) + str(right)
										| intlist:right ->		 				checkVarInList(left, right, "intlist") + str(left) + str(op) + str(right)
										| strlist:right -> 						checkVarInList(left, right, "strlist") + str(left) + str(op) + str(right)
										)


functioncall = allw '(' identifier:func w (w object)*:args w ')' w -> str(func) + '(' + str(','.join(args)) + ')'

if = '(' allw 'if' w condition:a allw statement*:b allw ')' allw -> 'if (' + str(a) + ') {\\n' + ''.join(b) + '\\n}'
functiondef = '(' allw 'func' w identifier:a w (w object)*:b allw statement*:c allw ')' allw -> moveFunction(str(returnTemplate(b)) + 'auto ' + str(a) + '(' + str(returnTypedParameters(b)) + ') {\\n' + ''.join(c) + '\\n}')

return = (
		allw 'return' w object:a w -> 'return ' + str(a)
		)

print = (
		allw 'println' w object:a w -> 'cout << ' + str(a) + ' << endl'
		| allw 'print' w object:a w -> 'cout << ' + str(a)
		)

read = (
		allw 'read' w identifier:a w -> 'getline(cin, ' + str(a) + ')'
		)

statement = ( allw comment
			| allw past_assignment:a endl allw  -> a + ";\\n"
			| allw print:a endl allw  -> a + ";\\n"
			| allw read:a endl allw  -> a + ";\\n"
			| allw return:a endl allw  -> a + ";\\n"
			| allw whileloop:a -> a + "\\n"
			| allw if:a -> a + "\\n"
			| allw elif:a -> a + "\\n"
			| allw else:a -> a + "\\n"
			| allw functiondef:a -> a + "\\n"
			| allw functioncall:a endl allw  -> a + ";\\n"
			)

expr = (
		statement+:a -> ''.join(a)
		)

# expr = (
# 		allw past_assignment:a endl allw  -> a + ";\\n"
# 		)

""", {"checkVarInList": checkVarInList, "returnTemplate": returnTemplate, "returnTypedParameters": returnTypedParameters, "moveFunction": moveFunction })

# while True:
# 	print (x(raw_input(">")).expr())


with open(sys.argv[1], "r") as f:
    script = f.read()
    f.close()
    script = "".join([s for s in script.splitlines(True) if s.strip("\r\n")])


# comment = pyparsing.nestedExpr(";", "!").suppress()
# script = comment.transformString(script)


translated = (x(script).expr())

with open(os.path.join(os.path.dirname(sys.argv[0]), "main.cpp"), "w+") as f:
	f.write("""
#include <iostream>
#include <vector>
using namespace std;

""")
	for func in listOfFunctions:
		print(func)
		f.write(func)
	f.write("int main() {")
	f.write(translated)
	f.write("}")
	f.close()

os.system("g++ -std=c++14 " + os.path.join(os.path.dirname(sys.argv[0]), "main.cpp") + "\nclear\n./a.out")


# assignInt = identifier:left '=' number:right !(l.append(left)) -> left '=' right



# math = number:left ( '+' math:right -> left + right
# 					| '*' math:right -> left * right
# 					| -> left)