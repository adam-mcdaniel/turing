
#include <iostream>
#include <vector>
using namespace std;

bool inStr(string s1, string s2){
    if (s1.find(s2) != string::npos) {
        return true;
    }
    else {
        return false;
    }
}

template<typename type0 >auto print(type0 a ) {
cout << a << endl;

}int main() {
int b=9;
while ( b >    0 ) {
cout << "b is greater than 1!" << endl;
b-=1;

}
int p=7;
if ( p ==    9 ) {
print("p is 9!");

}
else if ( p ==    8 ) {
print("p is 8!");

}
else {
print("p is not 8 or 9 :(");

}
print("All done!");
}