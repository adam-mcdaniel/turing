
#include <iostream>
#include <vector>
#include <sstream>
#include <string>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

template<typename T>
auto __Type__()
{
	T a;
	return a;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}


string get_char()
{
	string s;
 	stringstream ss;

	getline(cin, s);

	if (s.size() > 0)
	{
	 	ss << s.at(0);
	 	ss >> s;
	} else {
		s = " ";
	}

	return s;
}



int main(int argc,char* __char_argv__[])
{

	string __file__ = *__char_argv__;
string a="";
cout << __file__ << endl;

	return 0;

}

