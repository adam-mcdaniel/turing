
#include <iostream>
#include <vector>
#include <sstream>
#include <string>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value

bool inStr(string s1, string s2)
{
    if (s1.find(s2) != string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template<typename T>
auto __List__()
{
	vector <T> list;
	return list;
}

template<typename T>
auto __Type__()
{
	T a;
	return a;
}

auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}


string get_char()
{
	string s;
 	stringstream ss;

	getline(cin, s);

	if (s.size() > 0)
	{
	 	ss << s.at(0);
	 	ss >> s;
	} else {
		s = " ";
	}

	return s;
}

template<typename type0 >auto print(type0 a ) {
cout << a << endl;

}

class Atom {
public:
__auto_reserved__(name, "");__auto_reserved__(mass, 0);
auto print_info() {
print(name);
print(mass);

}
template<typename type0, typename type1 >
Atom (type0 n, type1 m ) {
name=n;
mass=m;

}

Atom () {
name="H";
mass=1;

}

};

class Mole {
public:
__auto_reserved__(number_of_atoms, "6.022*10^23 atoms in a mole");__auto_reserved__(atoms, __List__<Atom>());
auto print_info() {
print(number_of_atoms);
for (auto atom:atoms) {
atom.print_info();

}

}
template<typename type0, typename type1 >auto print_moles(type0 a, type1 moles ) {
auto store_moles=a.mass*moles;
cout << store_moles;
cout << " grams of ";
cout << a.name;
cout << " in ";
cout << moles;
if ( moles ==    1 ) {
cout << " mole" << endl;

}
else {
cout << " moles" << endl;

}

}

Mole () {
print_info();

}

};

auto start() {
auto m=Mole();
auto atom=Atom("Ca",40);
m.print_moles(atom,1);

}



int main(int argc,char* __char_argv__[])
{

	string __file__ = *__char_argv__;


start();

	return 0;

}

