
#include <iostream>
// #include <map>
#include <vector>
using namespace std;

#define __auto_reserved__(variable, value) std::decay<decltype(value)>::type variable = value


// template <typename T1, typename T2>
// auto mapp(T1 values, T2 fun) {
// 	std::vector<decltype(
// 		fun(std::declval<typename decltype(values)::value_type>()))> results{};
// 	for (auto v : values) {
// 		results.push_back(fun(v));
// 	}
// 	return results;
// }

template<typename T>
auto __List__() {
	vector <T> list;
	return list;
}

class Dog
{        
public:

	string name;
	__auto_reserved__(x, __List__<int>());

	template<typename T>
    Dog(T a) {
    	name = a;
    }

    void PrintName() {
    	cout << name << endl;
    }

};




// template<typename T>
// auto ReturnList() {
// 	vector <T> list;
// 	return list;
// }


auto range(int begin, int end)
{
	vector <int> r;
	for (int i = begin; i < end; i++)
	{
		r.push_back(i);
	}
	return r;
}



// template<typename T, typename T2>
// auto append(T *a, T2 b) {
// 	a.push_back(b);
// }

int main()
{

	// // x = (list [Dog])
	// __auto_reserved__(x, __List__<vector<int>>());
	__auto_reserved__(y, __List__<int>());
	
	y.append(0);


	// for (auto r : range(0,8))
	// {
	// 	x.push_back(y);
	// 	cout << "adding: " << r << endl;
	// }

	// // x.push_back(Dog("Hey there friend!"));

	// cout << "length: " << x.size() << endl;

	// // for (auto pup : x) // access by reference to avoid copying
	// // {  
	// // 	pup.PrintName();
	// // }

}