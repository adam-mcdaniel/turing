
#include <iostream>
// #include <map>
#include <vector>
using namespace std;

// template <typename T1, typename T2>
// auto mapp(T1 values, T2 fun) {
// 	std::vector<decltype(
// 		fun(std::declval<typename decltype(values)::value_type>()))> results{};
// 	for (auto v : values) {
// 		results.push_back(fun(v));
// 	}
// 	return results;
// }




template<>auto def() {
	cout<<9<<endl;
}

int main()
{
	auto d = "";
	string a = "";
	// cout << typeid(d).name() << endl;
	// cout << typeid(a).name() << endl;
	def("hey");
}